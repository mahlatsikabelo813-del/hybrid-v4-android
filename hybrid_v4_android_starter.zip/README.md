# Hybrid Trading Robot V4 — Android starter project

This starter packages the saved V4 HTML dashboard inside a basic Android WebView app.

## Important scope
- This is only a packaging starter for the existing V4 dashboard.
- It does NOT add Deriv account login, authenticated account data, or real order execution.
- Do not enter Deriv passwords or API tokens into the dashboard.
- Signals remain experimental and are not guaranteed to be profitable.

## Build from an Android phone using GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder (not the ZIP itself).
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Choose **Build Hybrid V4 APK** and tap **Run workflow**, or push the files to `main`.
4. Open the completed workflow run, find **Artifacts**, and download `Hybrid-V4-debug-APK`.
5. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser/files app.

## Before connecting an account
A secure Deriv API integration must be implemented and tested separately. Use Deriv's official documentation and a least-privilege authorisation flow. Test on demo first; do not enable live order execution until risk controls and order handling have been verified.
